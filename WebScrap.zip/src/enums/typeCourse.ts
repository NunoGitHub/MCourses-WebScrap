export enum TypeCourse {
  None = 0,
  Udemy = 1,
  Coursera = 2,
}
