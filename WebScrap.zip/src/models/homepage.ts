const  homepageHelper = require("../helper/homepage");

export async function GethomepageCourses() {

    try {
        const secondHandOrders = await homepageHelper.gethomepageCourses();
        return secondHandOrders;
        
    } catch (error) {
        throw  error;
    }
    
}