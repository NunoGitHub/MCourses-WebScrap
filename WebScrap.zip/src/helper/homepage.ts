import  db  from "../database/cockroachConnector";
const axios = require("axios");

exports.gethomepageCourses = async function () {
    // get returns header info
    let queryString = ` SELECT * FROM courses;`;

    const courses: any = await new Promise((resolve, reject) => {
        db.query(queryString, [], (err, result: any) => {
            if (err) {
                return reject(err);
            }
            return resolve(result);
        });
    });

    return courses;
};