import { CaptchaType } from "../enums/captchaType";

export interface Udemy{
    responseStatus: number;
    responseUrl:string;
    typeCaptcha:CaptchaType;

}