export interface Category{
    name:string;
    maxPage:number;
    currentPage:number;
    url:string;
}